package com.example.gametranslator

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object TranslationClient {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    // MyMemory offers limited free usage without an API key; availability/quotas may change.
    fun translate(text: String, callback: (String) -> Unit) {
        executor.execute {
            var result = ""
            var connection: HttpURLConnection? = null
            try {
                val encoded = URLEncoder.encode(text.take(4500), "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$encoded&langpair=en|ru")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("User-Agent", "GameTranslatorAndroid/0.1")
                }
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    val root = JSONObject(body)
                    result = root.optJSONObject("responseData")?.optString("translatedText", "") ?: ""
                    result = result.replace("&#39;", "'").replace("&quot;", "\\"")
                        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                }
            } catch (_: Exception) {
                result = ""
            } finally {
                connection?.disconnect()
            }
            if (result.isNotBlank()) main.post { callback(result) }
        }
    }
}
