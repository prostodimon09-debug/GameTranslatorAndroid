package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "game_translator_capture"
        private const val NOTIFICATION_ID = 101
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var handler: Handler? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private val busy = AtomicBoolean(false)
    private var lastText = ""
    private var lastTranslated = ""
    private var lastRequestAt = 0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        handlerThread = HandlerThread("screen-ocr").also { it.start() }
        handler = Handler(handlerThread!!.looper)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            processImage(image)
        }, handler)

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "GameTranslatorCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, handler
        )
        showOverlay()
    }

    private fun processImage(image: Image) {
        if (!busy.compareAndSet(false, true)) {
            image.close()
            return
        }
        try {
            val bitmap = ImageUtils.imageToBitmap(image)
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val text = result.text.lines().map { it.trim() }
                        .filter { it.length >= 2 }
                        .distinct().take(14).joinToString("\\n")
                    val now = System.currentTimeMillis()
                    if (text.isNotBlank() && text != lastText && now - lastRequestAt > 1800) {
                        lastText = text
                        lastRequestAt = now
                        TranslationClient.translate(text) { translated ->
                            if (translated.isNotBlank()) {
                                lastTranslated = translated
                                handler?.post { updateOverlay(translated) }
                            }
                        }
                    }
                    bitmap.recycle()
                    busy.set(false)
                }
                .addOnFailureListener {
                    bitmap.recycle()
                    busy.set(false)
                }
        } catch (_: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy.set(false)
        }
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        overlay = TextView(this).apply {
            text = "Game Translator: перевод появится здесь"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC202020.toInt())
            setPadding(18, 12, 18, 12)
        }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (resources.displayMetrics.heightPixels * 0.12f).toInt()
        }
        try { windowManager?.addView(overlay, params) } catch (_: Exception) {}
    }

    private fun updateOverlay(text: String) {
        overlay?.text = text.take(1800)
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Game Translator")
            .setContentText("Захват экрана и перевод активны")
            .setSmallIcon(android.R.drawable.ic_menu_translate)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "Game Translator", NotificationManager.IMPORTANCE_LOW
            ))
        }
    }

    override fun onDestroy() {
        try { windowManager?.removeView(overlay) } catch (_: Exception) {}
        overlay = null
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        handlerThread?.quitSafely()
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
